package com.example;

import com.example.domain.Employee;

public class EmployeeTest {

	
public static void main(String[] args) {
		
	Employee obj=new Employee();
	
	obj.setEmployeeId(101);
	obj.setEmployeeName("Jane Smith");
	obj.setEmployeeSSN("012-345-678");
	obj.setEmployeeSalary(1500);
	obj.setEmployeeNumber(2145007000);
	
	System.out.println(obj.getEmployeeId()+  " " + obj.getEmployeeSSN() + " " + obj.getEmployeeName() + " " + obj.getEmployeeSalary() + " " + obj.getEmployeeNumber());
	
	Employee obj1 = new Employee();
	
	obj1.setEmployeeId(500);
	obj1.setEmployeeName("Prajwal R");
	obj1.setEmployeeSSN("999-999-999");
	obj1.setEmployeeSalary(5000);
	obj1.setEmployeeNumber(2145007000);
	
	System.out.println(obj1.getEmployeeId()+  " " + obj1.getEmployeeSSN() + " " + obj1.getEmployeeName() + " " + obj1.getEmployeeSalary() + " " + obj1.getEmployeeNumber());
		
	}

}
