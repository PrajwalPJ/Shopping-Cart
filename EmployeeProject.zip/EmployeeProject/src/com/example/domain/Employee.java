package com.example.domain;

public class Employee {
	
 int EmployeeId;
 String EmployeeName;
 String EmployeeSSN;
 double EmployeeSalary;
 int EmployeeNumber;
	
	


	public int getEmployeeNumber() {
		return EmployeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		EmployeeNumber = employeeNumber;
	}

	public int getEmployeeId() {
		return EmployeeId;
	}

	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}

	public String getEmployeeName() {
		return EmployeeName;
	}

	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}

	public String getEmployeeSSN() {
		return EmployeeSSN;
	}

	public void setEmployeeSSN(String employeeSSN) {
		EmployeeSSN = employeeSSN;
	}

	public double getEmployeeSalary() {
		return EmployeeSalary;
	}

	public void setEmployeeSalary(double employeeSalary) {
		EmployeeSalary = employeeSalary;
	}

	public void setEmployeeAddress(String string) {
		// TODO Auto-generated method stub
		
	}

	
}
