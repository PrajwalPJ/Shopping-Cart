// POST = method will take pass the data as hidden data
//GET = will pass the data along with URL

package model;

import model.student;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.*;

public class NewServlet extends HttpServlet 
{

	protected void processRequest (HttpServletRequest, HttpServlet response)
		throws ServletException, IOException
		
		{
		
		}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServlet response)
			throws ServletException, IOException)

{
	response.setContentType("text/html;character=UTF-8");
	try(PrintWriter out = response.getWriter())
	{
		student s = new student("name");
		String name = request.getParameter(s.name);
		System.out.println(name);
	}
	
	if(name.equals(""))
	{
		request.getRequestDispather
	}
}
	
}
