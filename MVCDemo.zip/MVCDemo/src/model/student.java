package model;

public class student {

}
