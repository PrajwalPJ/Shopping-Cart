package com.niit.ShoppingCart.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller

public class HomeController 
{
	
	@RequestMapping("/")
	public String gotoHome()
	{
		return "index";
	}
		
	
	@RequestMapping("/Login")
	public String login ( Model model)
	{
		
		model.addAttribute("userClickedLogin", "true");
		return "login";
		
	}
	
	@RequestMapping("/Register")
	public String register (Model model)
	{
		model.addAttribute("userClickedRegister", "true");
		return "register";
		
	}
	
	@RequestMapping("/validate")
	public String validate(@RequestParam(name="userID") String id,
				@RequestParam(name="password") String pwd,
				Model model, HttpSession session)
	{
			if (id.equals("niit") && pwd.equals("niit"))
			{
				session.setAttribute("suckmessage", "You have successfully logged in");
				return "index";
			}
			else
			{
				model.addAttribute("suckmessage", "Invalid details. Please try again.");
			}
			
		return "index";
		
	}

}